# 📱 Mes Habitudes — PWA

Tracker d'habitudes installable sur iPhone.

---

## 🚀 Déployer sur Vercel (gratuit, 2 minutes)

### Option A — Glisser-déposer (le plus simple)

1. Va sur **vercel.com** → crée un compte gratuit (avec GitHub ou email)
2. Sur le dashboard, clique **"Add New Project"**
3. Clique **"Import"** → puis en bas **"Upload"** (ou glisse le dossier `habit-tracker`)
4. Vercel détecte automatiquement React → clique **"Deploy"**
5. En 30 secondes tu obtiens une URL du type `mes-habitudes.vercel.app`

### Option B — Via GitHub

1. Crée un repo GitHub avec ce dossier
2. Connecte-le à Vercel → déploiement automatique

---

## 📱 Installer sur iPhone (PWA)

Une fois l'URL obtenue :

1. Ouvre l'URL dans **Safari** (⚠️ pas Chrome)
2. Tape l'icône **Partager** ↑ en bas de Safari
3. Fais défiler → **"Sur l'écran d'accueil"**
4. Nomme l'app → **"Ajouter"**

L'app apparaît sur ton écran d'accueil comme une vraie app, en plein écran.

---

## 🛠 Développement local

```bash
npm install
npm start
```
