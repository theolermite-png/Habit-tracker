import { useState, useEffect, useCallback } from "react";

const DAYS = ["L", "M", "M", "J", "V", "S", "D"];
const FULL_DAYS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

const COLORS = [
  { accent: "#2E7D32" },
  { accent: "#1565C0" },
  { accent: "#E65100" },
  { accent: "#AD1457" },
  { accent: "#6A1B9A" },
  { accent: "#00695C" },
  { accent: "#F57F17" },
  { accent: "#4E342E" },
];

const ICONS = ["🏃", "📚", "💧", "🧘", "🥗", "💪", "🎯", "✍️", "🛌", "🎨", "🧹", "🌿"];

function getTodayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function getWeekKeys() {
  const keys = [];
  const today = new Date();
  const day = today.getDay();
  const monday = new Date(today);
  monday.setDate(today.getDate() - ((day + 6) % 7));
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    keys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`);
  }
  return keys;
}

function getLast30Keys() {
  const keys = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    keys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`);
  }
  return keys;
}

function getStreak(logs) {
  let streak = 0;
  const today = new Date();
  for (let i = 0; i < 365; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    if (logs[key]) streak++;
    else break;
  }
  return streak;
}

function getCompletionRate(logs) {
  const keys = getLast30Keys();
  const done = keys.filter((k) => logs[k]).length;
  return Math.round((done / 30) * 100);
}

export default function HabitTracker() {
  const [habits, setHabits] = useState(() => {
    try {
      const saved = localStorage.getItem("habits_v2");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [selectedHabit, setSelectedHabit] = useState(null);
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState("");
  const [newIcon, setNewIcon] = useState("🎯");
  const [newColor, setNewColor] = useState(0);
  const [animating, setAnimating] = useState(null);

  const today = getTodayKey();
  const weekKeys = getWeekKeys();

  useEffect(() => {
    try {
      localStorage.setItem("habits_v2", JSON.stringify(habits));
    } catch {}
  }, [habits]);

  const toggle = useCallback(
    (habitId) => {
      setAnimating(habitId);
      setTimeout(() => setAnimating(null), 400);
      setHabits((prev) =>
        prev.map((h) => {
          if (h.id !== habitId) return h;
          const logs = { ...h.logs };
          logs[today] = !logs[today];
          return { ...h, logs };
        })
      );
    },
    [today]
  );

  const addHabit = () => {
    if (!newName.trim()) return;
    const habit = {
      id: Date.now().toString(),
      name: newName.trim(),
      icon: newIcon,
      colorIdx: newColor,
      logs: {},
      createdAt: today,
    };
    setHabits((prev) => [...prev, habit]);
    setNewName("");
    setNewIcon("🎯");
    setNewColor(0);
    setAdding(false);
  };

  const deleteHabit = (id) => {
    setHabits((prev) => prev.filter((h) => h.id !== id));
    setSelectedHabit(null);
  };

  const completedToday = habits.filter((h) => h.logs[today]).length;
  const totalHabits = habits.length;
  const pct = totalHabits > 0 ? Math.round((completedToday / totalHabits) * 100) : 0;

  const circumference = 2 * Math.PI * 52;
  const dash = (pct / 100) * circumference;

  return (
    <div style={{
      minHeight: "100vh",
      minHeight: "100dvh",
      background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
      fontFamily: "'DM Sans', sans-serif",
      color: "#fff",
      overflowX: "hidden",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet" />

      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
        body { background: #1a1a2e; overscroll-behavior: none; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 2px; }
        @keyframes pop { 0%{transform:scale(1)} 50%{transform:scale(1.2)} 100%{transform:scale(1)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        @keyframes slideUp { from{opacity:0;transform:translateY(40px)} to{opacity:1;transform:translateY(0)} }
        .habit-card { transition: transform 0.2s; }
        .pop { animation: pop 0.4s cubic-bezier(.36,.07,.19,.97); }
        .add-sheet { animation: slideUp 0.3s ease both; }
        input::placeholder { color: rgba(255,255,255,0.3); }
        input { -webkit-appearance: none; }
        button { -webkit-appearance: none; }
      `}</style>

      <div style={{ maxWidth: 440, margin: "0 auto", padding: "env(safe-area-inset-top, 28px) 20px 110px", paddingTop: "max(env(safe-area-inset-top), 28px)" }}>

        {/* Header */}
        <div style={{ marginBottom: 28 }}>
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.45)", letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>
            {new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}
          </p>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 32, fontWeight: 700, lineHeight: 1.1 }}>
            Mes habitudes
          </h1>
        </div>

        {/* Progress ring */}
        {totalHabits > 0 && (
          <div style={{
            background: "rgba(255,255,255,0.05)",
            borderRadius: 20,
            padding: "24px 28px",
            marginBottom: 24,
            display: "flex",
            alignItems: "center",
            gap: 24,
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255,255,255,0.08)",
          }}>
            <div style={{ position: "relative", flexShrink: 0 }}>
              <svg width={120} height={120} style={{ transform: "rotate(-90deg)" }}>
                <circle cx={60} cy={60} r={52} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={8} />
                <circle cx={60} cy={60} r={52} fill="none"
                  stroke={pct === 100 ? "#4ade80" : "#60a5fa"}
                  strokeWidth={8}
                  strokeLinecap="round"
                  strokeDasharray={`${dash} ${circumference}`}
                  style={{ transition: "stroke-dasharray 0.6s cubic-bezier(0.4,0,0.2,1)" }}
                />
              </svg>
              <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
                <span style={{ fontSize: 26, fontWeight: 600 }}>{pct}%</span>
                <span style={{ fontSize: 11, color: "rgba(255,255,255,0.45)" }}>aujourd'hui</span>
              </div>
            </div>
            <div>
              <p style={{ fontSize: 15, color: "rgba(255,255,255,0.5)", marginBottom: 6 }}>Progression</p>
              <p style={{ fontSize: 28, fontWeight: 600, lineHeight: 1 }}>
                {completedToday}<span style={{ color: "rgba(255,255,255,0.35)", fontWeight: 400 }}>/{totalHabits}</span>
              </p>
              <p style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 6 }}>habitudes complètes</p>
              {pct === 100 && (
                <div style={{ marginTop: 10, fontSize: 13, color: "#4ade80", fontWeight: 500 }}>
                  🎉 Journée parfaite !
                </div>
              )}
            </div>
          </div>
        )}

        {/* Habits list */}
        {habits.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 20px", color: "rgba(255,255,255,0.3)" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>✨</div>
            <p style={{ fontSize: 16, marginBottom: 6 }}>Aucune habitude</p>
            <p style={{ fontSize: 13 }}>Ajoute ta première habitude ci-dessous</p>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 20 }}>
            {habits.map((h, i) => {
              const col = COLORS[h.colorIdx % COLORS.length];
              const done = !!h.logs[today];
              const streak = getStreak(h.logs);
              const weekDone = weekKeys.filter((k) => h.logs[k]).length;
              const isExpanded = selectedHabit === h.id;

              return (
                <div key={h.id} className={animating === h.id ? "pop" : ""}>
                  <div style={{
                    background: done ? `linear-gradient(135deg, ${col.accent}22, ${col.accent}11)` : "rgba(255,255,255,0.04)",
                    border: `1px solid ${done ? col.accent + "55" : "rgba(255,255,255,0.08)"}`,
                    borderRadius: isExpanded ? "16px 16px 0 0" : 16,
                    padding: "16px 18px",
                    display: "flex",
                    alignItems: "center",
                    gap: 14,
                    backdropFilter: "blur(8px)",
                  }}>
                    <button onClick={() => toggle(h.id)} style={{
                      width: 40, height: 40, borderRadius: 12,
                      border: `2px solid ${done ? col.accent : "rgba(255,255,255,0.2)"}`,
                      background: done ? col.accent : "transparent",
                      cursor: "pointer",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 18, flexShrink: 0,
                      transition: "all 0.2s",
                      color: "#fff",
                    }}>
                      {done ? "✓" : ""}
                    </button>

                    <div style={{ flex: 1, minWidth: 0 }} onClick={() => setSelectedHabit(isExpanded ? null : h.id)}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                        <span style={{ fontSize: 18 }}>{h.icon}</span>
                        <span style={{
                          fontSize: 15, fontWeight: 500,
                          textDecoration: done ? "line-through" : "none",
                          color: done ? "rgba(255,255,255,0.45)" : "#fff",
                          transition: "all 0.2s",
                          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap"
                        }}>
                          {h.name}
                        </span>
                      </div>
                      <div style={{ display: "flex", gap: 4 }}>
                        {weekKeys.map((k, wi) => (
                          <div key={k} style={{
                            width: 22, height: 6, borderRadius: 3,
                            background: h.logs[k] ? col.accent : k === today ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.08)",
                            transition: "background 0.3s",
                          }} />
                        ))}
                      </div>
                    </div>

                    {streak > 0 && (
                      <div style={{ flexShrink: 0, textAlign: "center", background: "rgba(255,255,255,0.06)", borderRadius: 10, padding: "6px 10px" }}>
                        <div style={{ fontSize: 16 }}>🔥</div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: "#fb923c" }}>{streak}j</div>
                      </div>
                    )}
                  </div>

                  {isExpanded && (
                    <div style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.06)",
                      borderTop: "none",
                      borderRadius: "0 0 16px 16px",
                      padding: "16px 18px",
                      animation: "fadeIn 0.2s ease",
                    }}>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 14 }}>
                        {[
                          { label: "Série", value: `${streak}j`, icon: "🔥" },
                          { label: "Cette sem.", value: `${weekDone}/7`, icon: "📅" },
                          { label: "30 jours", value: `${getCompletionRate(h.logs)}%`, icon: "📊" },
                        ].map((s) => (
                          <div key={s.label} style={{ background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: "10px 12px", textAlign: "center" }}>
                            <div style={{ fontSize: 18, marginBottom: 4 }}>{s.icon}</div>
                            <div style={{ fontSize: 17, fontWeight: 600 }}>{s.value}</div>
                            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{s.label}</div>
                          </div>
                        ))}
                      </div>

                      <div style={{ marginBottom: 14 }}>
                        <p style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginBottom: 8, letterSpacing: 1 }}>30 DERNIERS JOURS</p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
                          {getLast30Keys().map((k) => (
                            <div key={k} style={{
                              width: 14, height: 14, borderRadius: 3,
                              background: h.logs[k] ? col.accent : "rgba(255,255,255,0.08)",
                              transition: "background 0.2s"
                            }} />
                          ))}
                        </div>
                      </div>

                      <button onClick={() => deleteHabit(h.id)} style={{
                        background: "rgba(239,68,68,0.1)",
                        border: "1px solid rgba(239,68,68,0.3)",
                        color: "#f87171",
                        borderRadius: 10, padding: "8px 16px",
                        fontSize: 13, cursor: "pointer", fontFamily: "inherit"
                      }}>
                        Supprimer cette habitude
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Weekly bar chart */}
        {habits.length > 0 && (
          <div style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 16, padding: "16px 20px",
            marginBottom: 20,
          }}>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", letterSpacing: 1, marginBottom: 12 }}>SEMAINE EN COURS</p>
            <div style={{ display: "flex", gap: 6 }}>
              {weekKeys.map((k, i) => {
                const doneCt = habits.filter((h) => h.logs[k]).length;
                const pctDay = totalHabits > 0 ? doneCt / totalHabits : 0;
                const isToday = k === today;
                return (
                  <div key={k} style={{ flex: 1, textAlign: "center" }}>
                    <div style={{ fontSize: 10, color: isToday ? "#60a5fa" : "rgba(255,255,255,0.3)", marginBottom: 6, fontWeight: isToday ? 600 : 400 }}>
                      {DAYS[i]}
                    </div>
                    <div style={{
                      height: 48, borderRadius: 6, position: "relative", overflow: "hidden",
                      background: "rgba(255,255,255,0.06)",
                      border: isToday ? "1px solid rgba(96,165,250,0.4)" : "1px solid transparent"
                    }}>
                      <div style={{
                        position: "absolute", bottom: 0, left: 0, right: 0,
                        height: `${pctDay * 100}%`,
                        background: pctDay === 1 ? "#4ade80" : "#60a5fa",
                        borderRadius: 5,
                        transition: "height 0.6s cubic-bezier(0.4,0,0.2,1)",
                        opacity: pctDay > 0 ? 1 : 0.3,
                      }} />
                    </div>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 5 }}>{doneCt}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Add habit sheet */}
      {adding && (
        <div style={{
          position: "fixed", inset: 0,
          background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)",
          zIndex: 100, display: "flex", alignItems: "flex-end"
        }} onClick={(e) => e.target === e.currentTarget && setAdding(false)}>
          <div className="add-sheet" style={{
            width: "100%", maxWidth: 440, margin: "0 auto",
            background: "linear-gradient(180deg, #1e293b, #0f172a)",
            borderRadius: "24px 24px 0 0",
            padding: "24px 24px",
            paddingBottom: "max(env(safe-area-inset-bottom), 32px)",
            border: "1px solid rgba(255,255,255,0.1)",
          }}>
            <div style={{ width: 36, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.2)", margin: "0 auto 24px" }} />
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, marginBottom: 20 }}>Nouvelle habitude</h2>

            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addHabit()}
              placeholder="Ex: Méditer 10 minutes..."
              autoFocus
              style={{
                width: "100%", padding: "14px 16px",
                background: "rgba(255,255,255,0.07)",
                border: "1px solid rgba(255,255,255,0.15)",
                borderRadius: 14, color: "#fff",
                fontSize: 16, fontFamily: "inherit",
                outline: "none", marginBottom: 18,
              }}
            />

            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 10, letterSpacing: 1 }}>ICÔNE</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 18 }}>
              {ICONS.map((ic) => (
                <button key={ic} onClick={() => setNewIcon(ic)} style={{
                  width: 44, height: 44, borderRadius: 10, fontSize: 22,
                  background: ic === newIcon ? "rgba(96,165,250,0.25)" : "rgba(255,255,255,0.07)",
                  border: ic === newIcon ? "2px solid #60a5fa" : "2px solid transparent",
                  cursor: "pointer", transition: "all 0.15s",
                }}>{ic}</button>
              ))}
            </div>

            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 10, letterSpacing: 1 }}>COULEUR</p>
            <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
              {COLORS.map((c, i) => (
                <button key={i} onClick={() => setNewColor(i)} style={{
                  width: 32, height: 32, borderRadius: "50%",
                  background: c.accent,
                  border: i === newColor ? "3px solid #fff" : "3px solid transparent",
                  cursor: "pointer", transition: "all 0.15s",
                }} />
              ))}
            </div>

            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={() => setAdding(false)} style={{
                flex: 1, padding: "14px",
                background: "rgba(255,255,255,0.07)",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 14, color: "rgba(255,255,255,0.6)",
                fontSize: 15, fontFamily: "inherit", cursor: "pointer"
              }}>Annuler</button>
              <button onClick={addHabit} style={{
                flex: 2, padding: "14px",
                background: newName.trim() ? "linear-gradient(135deg, #3b82f6, #6366f1)" : "rgba(255,255,255,0.1)",
                border: "none",
                borderRadius: 14, color: newName.trim() ? "#fff" : "rgba(255,255,255,0.3)",
                fontSize: 15, fontWeight: 600, fontFamily: "inherit",
                cursor: newName.trim() ? "pointer" : "default",
                transition: "all 0.2s"
              }}>Ajouter</button>
            </div>
          </div>
        </div>
      )}

      {/* FAB */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        paddingBottom: "max(env(safe-area-inset-bottom), 24px)",
        paddingTop: 16,
        display: "flex", justifyContent: "center",
        background: "linear-gradient(to top, rgba(15,52,96,0.95) 0%, transparent 100%)",
        pointerEvents: "none",
      }}>
        <button onClick={() => setAdding(true)} style={{
          background: "linear-gradient(135deg, #3b82f6, #6366f1)",
          border: "none", borderRadius: 20,
          padding: "15px 28px",
          color: "#fff", fontSize: 15, fontWeight: 600,
          fontFamily: "inherit", cursor: "pointer",
          boxShadow: "0 8px 32px rgba(99,102,241,0.5)",
          display: "flex", alignItems: "center", gap: 8,
          letterSpacing: 0.3,
          pointerEvents: "all",
        }}>
          <span style={{ fontSize: 20 }}>+</span> Nouvelle habitude
        </button>
      </div>
    </div>
  );
}
